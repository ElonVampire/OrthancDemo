#ifndef ECGWAVEPLOT_H
#define ECGWAVEPLOT_H

#include <QObject>
#include "qcustomplot.h"
#include "datasampler.h"

class ECGWavePlot : public QObject
{
    Q_OBJECT
public:
    explicit ECGWavePlot(QCustomPlot *customPlot, double startTime, QObject *parent = nullptr)
        : QObject(parent), customPlot(customPlot), dataBufferMaxSize(500),
        windowSize(10.0), currentTime(startTime), drawingPaused(false)
    {
        vecData.clear();
        vecData.resize(sampleSec *sampleSizePerSec);
        for(unsigned int i = 0; i < sampleSec * sampleSizePerSec; i++)
            vecData[0] = 0.0;

        // 创建数据采样Actor
        dataSampler = new DataSampler(sampleSec, sampleSizePerSec, 50);
        dataSamplerThread = new QThread(this);
        dataSampler->moveToThread(dataSamplerThread);
        dataSamplerThread->start();

        // 连接数据采样信号与槽
        qRegisterMetaType<QVector<double>>("QVector<double>");
        connect(dataSampler, SIGNAL( dataSampled(const QVector<double>&) ), this, SLOT( updateDataBuffer(const QVector<double>&) ) );
        connect(this, SIGNAL( notifySamplingStart()), dataSampler, SLOT( startSampling()) );
        connect(this, SIGNAL( notifySamplingStop()), dataSampler, SLOT( stopSampling()) );

        // 创建定时器，设置更新频率（毫秒）
        timer = new QTimer(this);
        connect(timer, &QTimer::timeout, this, &ECGWavePlot::updateImage);
        timer->start(10); // 设置每100毫秒更新一次

        // 创建QCustomPlot并设置属性
        QPointer<QCPGraph> mGraph = customPlot->addGraph();
        //customPlot->xAxis->setLabel("时间");
        //customPlot->yAxis->setLabel("振幅");
        customPlot->xAxis->setRange(0, sampleSec * sampleSizePerSec);
        customPlot->yAxis->setRange(1, 3); // 适当设置振幅范围
        customPlot->xAxis->setTickLabels(false);
        customPlot->yAxis->setTickLabels(false);
        customPlot->xAxis->grid()->setVisible(false);
        customPlot->yAxis->grid()->setVisible(false);
        customPlot->setBackground(Qt::black);

        customPlot->setAntialiasedElement(QCP::aePlottables);    //** 启用抗锯齿渲染可以使波形线条看起来更加平滑
        mGraph->setAdaptiveSampling(true);

        mGraph->setPen(QPen(QColor(0, 180, 60), 2));
    }

    ~ECGWavePlot()
    {
        pauseDrawing(false);
        dataSamplerThread->quit();
        dataSamplerThread->wait();
        delete dataSamplerThread;
        delete dataSampler;
    }

    void pauseDrawing(bool paused)
    {
        drawingPaused = paused;
    }

signals:
    void notifySamplingStart();
    void notifySamplingStop();

public:
    void notifySampling(bool start)
    {
        if(start)
            emit notifySamplingStart();
        else
            emit notifySamplingStop();
    }

private slots:
    void updateDataBuffer(const QVector<double>& sample)
    {
        QMutexLocker locker(&dataMutex);
        vecData = sample;
//        if (dataBuffer.size() > dataBufferMaxSize) {
//            dataBuffer.pop_front();
//        }
    }

 public slots:
    void updateImage()
    {
        if (drawingPaused) {
            return; // 如果绘制暂停，则不进行绘制
        }

        // 更新图片内存
        customPlot->graph(0)->data().clear();
        QVector<double> xData, yData;
//        double x = currentTime - windowSize;
        {
            QMutexLocker locker(&dataMutex);
            for (unsigned int i = 0; i < sampleSec * sampleSizePerSec; i++)
            {
                xData.append(i);
                if(fabs(vecData[i]) < 1e-15)
                {
                    yData.append(qQNaN());
                }
                else
                {
                    yData.append(vecData[i]);
                }
            }
        }
//        {
//            QMutexLocker locker(&dataMutex);
//            for (const ECGSample &sample : dataBuffer) {
//                double xPosition = x - currentTime + windowSize;
//                if (xPosition >= 0 && xPosition <= windowSize) {
//                    xData.append(xPosition);
//                    yData.append(sample.value);
//                }
//                x += 0.1; // 假设每次更新增加0.1秒
//            }
//        }

        // 在QCustomPlot中设置数据
        customPlot->graph(0)->setData(xData, yData);
        customPlot->replot();
        qDebug() << "replot id:" << QThread::currentThreadId();
    }

public:
    void setStartTime(double startTime)
    {
        currentTime = startTime;
    }

private:
    QCustomPlot *customPlot;
    int dataBufferMaxSize;
    QMutex dataMutex;
//    QVector<ECGSample> dataBuffer;
    QVector<double> vecData;
    double windowSize;
    double currentTime;
    bool drawingPaused;

    DataSampler *dataSampler;
    QThread *dataSamplerThread;
    QTimer *timer;
    int sampleSec = 5;
    int sampleSizePerSec = 50;
};

#endif // ECGWAVEPLOT_H
