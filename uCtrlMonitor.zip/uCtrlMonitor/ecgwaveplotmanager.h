#ifndef ECGWAVEPLOTMANAGER_H
#define ECGWAVEPLOTMANAGER_H

#include <QObject>
#include <QTimer>
#include "qcustomplot.h"
#include "ecgwaveplot.h"
#include <QVBoxLayout>
#include <QGridLayout>

class ECGWavePlotManager : public QObject
{
    Q_OBJECT
public:
    ECGWavePlotManager(QObject *parent = nullptr)
        : QObject(parent)
        , startTime(0.0)
    {
        // 创建一个时间定时器，用于驱动ECG监视器的绘制
//        timer = new QTimer(this);
//        connect(timer, &QTimer::timeout, this, &ECGWavePlotManager::updateMonitors);
//        timer->start(100); // 设置每100毫秒更新一次

        QGridLayout* vLayout = new QGridLayout;
        vLayout->setSpacing(0);
        vLayout->setMargin(0);

        // 创建多个ECG监视器
        for (int i = 0; i < 3; ++i) {
            QCustomPlot *customPlot = new QCustomPlot;
            customPlot->setMinimumSize(300, 100); // 设置最小大小
            ECGWavePlot *monitor = new ECGWavePlot(customPlot, startTime);
            monitors.append(QSharedPointer<ECGWavePlot>(monitor));

            //if (i == 2)
            //{
            //    customPlot->setAntialiasedElement(QCP::aePlottables);    //** 启用抗锯齿渲染可以使波形线条看起来更加平滑
            //    customPlot->graph(0)->setAdaptiveSampling(true);
            //}

            vLayout->addWidget(customPlot, i % 3, 0);
            // 增加每个监视器的起始时间，以便它们在时间上错开
//            startTime += 10.0; // 假设每个监视器的起始时间相差10秒

            monitor->notifySampling(true);
        }

        ((QMainWindow*)parent)->centralWidget()->setLayout(vLayout);
        qDebug() << "main id:" << QThread::currentThreadId();
    }

    void pauseAllMonitors(bool paused)
    {
        for (const QSharedPointer<ECGWavePlot> &monitor : monitors) {
            monitor->pauseDrawing(paused);
        }
    }

    ~ECGWavePlotManager()
    {
        monitors.clear();
    }

private slots:
    void updateMonitors()
    {
        for (const QSharedPointer<ECGWavePlot> &monitor : monitors) {
            monitor->updateImage();
        }
    }

private:
    QTimer *timer;
    QVector<QSharedPointer<ECGWavePlot>> monitors;
    double startTime;
};


#endif // ECGWAVEPLOTMANAGER_H
