#include "uCtrlMonitor.h"

uCtrlMonitor::uCtrlMonitor(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);

    setGeometry(0, 0, 700, 900);

    qDebug() << "main id:" << QThread::currentThreadId();

    manager = new ECGWavePlotManager(this);
}
