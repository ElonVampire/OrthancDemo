#include "ecgwaveplot.h"

//ECGWavePlot::ECGWavePlot(QObject *parent)
//    : QObject{parent}
//{

//}
