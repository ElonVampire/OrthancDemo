#include "datasampler.h"

//DataSampler::DataSampler()
//{

//}
