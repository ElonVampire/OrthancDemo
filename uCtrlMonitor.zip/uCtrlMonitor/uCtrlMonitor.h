#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_uCtrlMonitor.h"

#include "ecgwaveplotmanager.h"
class uCtrlMonitor : public QMainWindow
{
    Q_OBJECT

public:
    uCtrlMonitor(QWidget *parent = Q_NULLPTR);

private:
    Ui::uCtrlMonitorClass ui;
    ECGWavePlotManager* manager;
};
