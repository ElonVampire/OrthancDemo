#ifndef DATASAMPLER_H
#define DATASAMPLER_H

#include <QObject>
#include <QThread>
#include <QtMath>
#include <QDebug>
#include <QTimer>
#include <QVector>

struct ECGSample
{
    double timestamp;
    double value;
};

class DataSampler : public QObject
{
    Q_OBJECT
public:
    DataSampler(int sec, int sizeSec, int ms, QObject *parent = nullptr)
        : QObject(parent)
        , sampleSeconds(sec)
        , sampleSizePerSec(sizeSec)
        , sampleMs(ms)
    {
        sampling = false;

        vecSample.clear();
        vecSample.resize(sampleSeconds * sampleSizePerSec);
        for(int i = 0 ; i < sampleSeconds * sampleSizePerSec; i++)
        {
            vecSample[i] = 0.0;
        }
        currentIdx = 0;
    }
    ~DataSampler()
    {

    };



public slots:
    void startSampling()
    {
        if (!sampling) {
            sampling = true;
            QTimer::singleShot(10, this, SLOT(sampleData()));
        }
    }
public slots:
    void stopSampling()
    {
        if (sampling) {
            sampling = false;
        }
    }
public:
    bool isSampling() const
    {
        return sampling;
    }

signals:
//    void dataSampled(const ECGSample &sample);
    void dataSampled(const QVector<double>& sample);

public slots:
    void sampleData()
    {
        while (sampling) {
//            ECGSample sample;
//            sample.timestamp = currentTime;
//            sample.value = qSin(2 * M_PI * sample.timestamp);
            if(currentIdx > sampleSeconds * sampleSizePerSec - 1)
                currentIdx = 0;

            
            double value = qSin(2 * M_PI * (currentIdx % sampleSizePerSec) / sampleSizePerSec*2) + 2.0;
            vecSample[currentIdx] = value;
            //double value = qSin(2 * M_PI * (currentIdx % sampleSizePerSec) / sampleSizePerSec * 2  ) + 2.0;
            //int iSec = currentIdx / (sampleSizePerSec / 2);
            //vecSample[currentIdx] = (iSec % 2 == 0) ? 2 : value;

            for(int i = 1; i < 3; i++)
            {
                if(currentIdx + i > sampleSeconds * sampleSizePerSec - 1)
                    break;
                vecSample[currentIdx + i] = 0.0;
            }

            emit dataSampled(vecSample);

//            currentTime += 0.1; // 模拟每0.1秒采样一次
            currentIdx ++;
            QThread::msleep(sampleMs); // 模拟实时采样
//            qDebug() << "sample id:" << QThread::currentThreadId();
        }
    }

private:
    bool sampling;
//    double currentTime;

    QVector<double> vecSample;
    int sampleSeconds;
    int sampleSizePerSec;
    int currentIdx;
    int sampleMs;

};


#endif // DATASAMPLER_H
