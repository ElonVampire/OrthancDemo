#include "ecgwaveplotmanager.h"

//ECGWavePlotManager::ECGWavePlotManager(QObject *parent)
//    : QObject{parent}
//{

//}
