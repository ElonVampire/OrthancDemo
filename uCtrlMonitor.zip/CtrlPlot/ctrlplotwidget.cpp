#include "ctrlplotwidget.h"
#include <QHBoxLayout>
CtrlPlotWidget::CtrlPlotWidget(QWidget *parent) : QWidget(parent),
    mPlot(0)
{
    QHBoxLayout* hLayout = new QHBoxLayout;

    mPlot = new QCustomPlot(this);
    mPlot->installEventFilter(this);
//    mPlot->setOpenGl(true);

    hLayout->addWidget(mPlot);
    hLayout->setSpacing(0);
    hLayout->setMargin(0);

    setLayout(hLayout);

    // configure plot to have two right axes:
    mPlot->yAxis->setTickLabels(false);
    connect(mPlot->yAxis2, SIGNAL(rangeChanged(QCPRange)), mPlot->yAxis, SLOT(setRange(QCPRange))); // left axis only mirrors inner right axis
    mPlot->yAxis2->setVisible(true);
    mPlot->axisRect()->addAxis(QCPAxis::atRight);
    mPlot->axisRect()->axis(QCPAxis::atRight, 0)->setPadding(30); // add some padding to have space for tags
    mPlot->axisRect()->axis(QCPAxis::atRight, 1)->setPadding(30); // add some padding to have space for tags

    mPlot->xAxis->grid()->setVisible(false);
    mPlot->yAxis->grid()->setVisible(false);
    mPlot->axisRect()->setAutoMargins(0x00);


//    mPlot->setBackground(QBrush(QColor(0,0,0/*,0*/)));
    mPlot->setBackground(Qt::black);
//    mPlot->setAntialiasedElement(QCP::aePlottables);    //** 启用抗锯齿渲染可以使波形线条看起来更加平滑
//    mPlot->setPlottingHint()
    // create graphs:
    mGraph1 = mPlot->addGraph(mPlot->xAxis, mPlot->axisRect()->axis(QCPAxis::atRight, 0));
//    mGraph1->setAdaptiveSampling(true);
    mGraph2 = mPlot->addGraph(mPlot->xAxis, mPlot->axisRect()->axis(QCPAxis::atRight, 1));
    mGraph1->setPen(QPen(QColor(250, 120, 0), 1));
    mGraph2->setPen(QPen(QColor(0, 180, 60), 2));

    // create tags with newly introduced AxisTag class (see axistag.h/.cpp):
//    mTag1 = new AxisTag(mGraph1->valueAxis());
//    mTag1->setPen(mGraph1->pen());
//    mTag2 = new AxisTag(mGraph2->valueAxis());
//    mTag2->setPen(mGraph2->pen());

}

//void CtrlPlotWidget::timerSlot()
void CtrlPlotWidget::replot()
{
  // calculate and add a new data point to each graph:
  mGraph1->addData(mGraph1->dataCount(), qSin(mGraph1->dataCount()/50.0)+qSin(mGraph1->dataCount()/50.0/0.3843)*0.25);
  mGraph2->addData(mGraph2->dataCount(), qCos(mGraph2->dataCount()/50.0)+qSin(mGraph2->dataCount()/50.0/0.4364)*0.15);

  // make key axis range scroll with the data:
  mPlot->xAxis->rescale();
  mGraph1->rescaleValueAxis(false, true);
  mGraph2->rescaleValueAxis(false, true);
  mPlot->xAxis->setRange(mPlot->xAxis->range().upper, 1000, Qt::AlignRight);

  qDebug() << "x range: " << mPlot->xAxis->range().size();
  // update the vertical axis tag positions and texts to match the rightmost data point of the graphs:
//  double graph1Value = mGraph1->dataMainValue(mGraph1->dataCount()-1);
//  double graph2Value = mGraph2->dataMainValue(mGraph2->dataCount()-1);
//  mTag1->updatePosition(graph1Value);
//  mTag2->updatePosition(graph2Value);
//  mTag1->setText(QString::number(graph1Value, 'f', 2));
//  mTag2->setText(QString::number(graph2Value, 'f', 2));

//  mPlot->replot(QCustomPlot::rpQueuedReplot);
  mPlot->replot();
}


bool CtrlPlotWidget::eventFilter(QObject *watched, QEvent *event)
{
  bool bRet = false;
  if(watched==mPlot)
  {
      if(event->type()==QEvent::MouseButtonPress)
      {
          bRet = true;
      }
      if(event->type()==QEvent::MouseMove)
      {
          bRet = true;
      }
      if(event->type()==QEvent::MouseButtonDblClick)
      {
          bRet = true;
      }
      if(event->type()==QEvent::MouseMove)
      {
          bRet = true;
      }
      if(event->type()==QEvent::Wheel)
      {
          bRet = true;
      }
      if(event->type()==QEvent::Enter)
      {
          bRet = true;
      }
      if(event->type()==QEvent::Leave)
      {
          bRet = true;
      }
      if(event->type()==QEvent::HoverEnter)
      {
          bRet = true;
      }
      if(event->type()==QEvent::HoverLeave)
      {
          bRet = true;
      }
      if(event->type()==QEvent::HoverMove)
      {
          bRet = true;
      }
  }
  return bRet;
}
