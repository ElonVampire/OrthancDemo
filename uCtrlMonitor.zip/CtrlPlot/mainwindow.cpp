/***************************************************************************
**                                                                        **
**  QCustomPlot, an easy to use, modern plotting widget for Qt            **
**  Copyright (C) 2011-2022 Emanuel Eichhammer                            **
**                                                                        **
**  This program is free software: you can redistribute it and/or modify  **
**  it under the terms of the GNU General Public License as published by  **
**  the Free Software Foundation, either version 3 of the License, or     **
**  (at your option) any later version.                                   **
**                                                                        **
**  This program is distributed in the hope that it will be useful,       **
**  but WITHOUT ANY WARRANTY; without even the implied warranty of        **
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         **
**  GNU General Public License for more details.                          **
**                                                                        **
**  You should have received a copy of the GNU General Public License     **
**  along with this program.  If not, see http://www.gnu.org/licenses/.   **
**                                                                        **
****************************************************************************
**           Author: Emanuel Eichhammer                                   **
**  Website/Contact: https://www.qcustomplot.com/                         **
**             Date: 06.11.22                                             **
**          Version: 2.1.1                                                **
****************************************************************************/

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QGridLayout>
#include <QApplication>
#include <QDebug>
#include <QThread>
#include <QHBoxLayout>
MainWindow::MainWindow(QWidget *parent) :
  QMainWindow(parent),
  ui(new Ui::MainWindow)
{
  ui->setupUi(this);
//  resize(1080,720);
  setGeometry(0, 0, 1500, 400);
  QGridLayout* gridLayout = new QGridLayout;
  gridLayout->setSpacing(0);
  gridLayout->setMargin(0);

  for(unsigned int i = 0; i < 36; i++)
  {
      CtrlPlotWidget* pCtrlPlot = new CtrlPlotWidget(this);
      if(i == 0)
      {
          pCtrlPlot->GetPlot()->setAntialiasedElement(QCP::aePlottables);    //** 启用抗锯齿渲染可以使波形线条看起来更加平滑
          pCtrlPlot->GetGraph1()->setAdaptiveSampling(true);
      }
      gridLayout->addWidget(pCtrlPlot, i/6, i%6);
      vecCtrlPlot.push_back(pCtrlPlot);
  }

  ui->centralWidget->setLayout(gridLayout);

  connect(&mDataTimer, SIGNAL(timeout()), this, SLOT(timerSlot()));
  mDataTimer.start(20);

  qDebug() << "main id:" << QThread::currentThreadId();
}

MainWindow::~MainWindow()
{
  delete ui;
}

void MainWindow::timerSlot()
{
    static QTime timeStart = QTime::currentTime();
    // calculate two new data points:
    double key = timeStart.msecsTo(QTime::currentTime())/1000.0; // time elapsed since start of demo, in seconds
    static double lastPointKey = 0;
    lastPointKey = key;

    for(unsigned int i = 0; i < 36; i++)
    {
        vecCtrlPlot[i]->replot();
    }

    // calculate frames per second:
    static double lastFpsKey;
    static int frameCount;
    ++frameCount;
    if (key-lastFpsKey > 2) // average fps over 2 seconds
    {
      ui->statusBar->showMessage(
//            QString("%1 FPS, Total Data points: %2")
            QString("%1 FPS")
            .arg(frameCount/(key-lastFpsKey), 0, 'f', 0)
            , 0);
      lastFpsKey = key;
      frameCount = 0;
    }
    qDebug() << "timerSlot id:" << QThread::currentThreadId();
    QCoreApplication::processEvents();
}
