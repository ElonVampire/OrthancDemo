#ifndef CTRLPLOTWIDGET_H
#define CTRLPLOTWIDGET_H

#include <QWidget>
#include "qcustomplot.h"
//#include "axistag.h"

class CtrlPlotWidget : public QWidget
{
    Q_OBJECT
public:
    explicit CtrlPlotWidget(QWidget *parent = 0);

    void replot();
    QCustomPlot* GetPlot() { return mPlot;}
    QPointer<QCPGraph>& GetGraph1() { return mGraph1;}
    QPointer<QCPGraph>& GetGraph2() { return mGraph2;}


private:
  QCustomPlot *mPlot;
  QPointer<QCPGraph> mGraph1;
  QPointer<QCPGraph> mGraph2;
//  AxisTag *mTag1;
//  AxisTag *mTag2;


  // QObject interface
public:
  bool eventFilter(QObject *watched, QEvent *event);
};

#endif // CTRLPLOTWIDGET_H
