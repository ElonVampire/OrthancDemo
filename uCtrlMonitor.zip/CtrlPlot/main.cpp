#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
  QApplication a(argc, argv);
  MainWindow w;
  w.show();
  
  return a.exec();
}

/*
#include <QApplication>
#include <QThread>
#include <QTimer>
#include <QMutex>
#include <QVector>
#include <QSharedPointer>
#include "qcustomplot.h"

// 模拟的ECG数据结构，包含时间戳和采样数据
struct ECGSample
{
    double timestamp;
    double value;
};

class DataSampler : public QObject
{
    Q_OBJECT
public:
    DataSampler(QObject *parent = nullptr)
        : QObject(parent), sampling(false), currentTime(0.0)
    {
    }

    void startSampling()
    {
        if (!sampling) {
            sampling = true;
            emit samplingStarted();
        }
    }

    void stopSampling()
    {
        if (sampling) {
            sampling = false;
            emit samplingStopped();
        }
    }

    bool isSampling() const
    {
        return sampling;
    }

signals:
    void dataSampled(const ECGSample &sample);
    void samplingStarted();
    void samplingStopped();

public slots:
    void sampleData()
    {
        while (sampling) {
            ECGSample sample;
            sample.timestamp = currentTime;
            sample.value = qSin(2 * M_PI * sample.timestamp); // 模拟ECG波形
            emit dataSampled(sample);
            currentTime += 0.1; // 模拟每0.1秒采样一次
            QThread::msleep(100); // 模拟实时采样
        }
    }

private:
    bool sampling;
    double currentTime;
};

class ECGMonitor : public QObject
{
    Q_OBJECT
public:
    explicit ECGMonitor(QCustomPlot *customPlot, double startTime, QObject *parent = nullptr)
        : QObject(parent), customPlot(customPlot), dataBufferMaxSize(500),
        windowSize(10.0), currentTime(startTime), drawingPaused(false)
    {
        // 创建数据采样Actor
        dataSampler = new DataSampler;
        dataSamplerThread = new QThread;
        dataSampler->moveToThread(dataSamplerThread);

        // 连接数据采样信号与槽
        connect(dataSampler, SIGNAL(DataSampler::dataSampled, this, &ECGMonitor::updateDataBuffer);
        connect(dataSampler, &DataSampler::samplingStarted, dataSamplerThread, &QThread::start);
        connect(dataSampler, &DataSampler::samplingStopped, dataSamplerThread, &QThread::quit);

        // 创建定时器，设置更新频率（毫秒）
        timer = new QTimer(this);
        connect(timer, &QTimer::timeout, this, &ECGMonitor::updateImage);
        timer->start(100); // 设置每100毫秒更新一次

        // 创建QCustomPlot并设置属性
        customPlot->addGraph();
        customPlot->xAxis->setLabel("时间");
        customPlot->yAxis->setLabel("振幅");
        customPlot->xAxis->setRange(0, windowSize);
        customPlot->yAxis->setRange(-1, 1); // 适当设置振幅范围
    }

    ~ECGMonitor()
    {
        dataSampler->stopSampling();
        dataSamplerThread->quit();
        dataSamplerThread->wait();
        delete dataSamplerThread;
        delete dataSampler;
    }

    void pauseDrawing(bool paused)
    {
        drawingPaused = paused;
    }

private slots:
    void updateDataBuffer(const ECGSample &sample)
    {
        QMutexLocker locker(&dataMutex);
        dataBuffer.append(sample);

        if (dataBuffer.size() > dataBufferMaxSize) {
            dataBuffer.pop_front();
        }
    }
public slots:
    void updateImage()
    {
        if (drawingPaused) {
            return; // 如果绘制暂停，则不进行绘制
        }

        // 更新图片内存
        customPlot->graph(0)->data().clear();
        QVector<double> xData, yData;
        double x = currentTime - windowSize;

        {
            QMutexLocker locker(&dataMutex);
            for (const ECGSample &sample : dataBuffer) {
                double xPosition = x - currentTime + windowSize;
                if (xPosition >= 0 && xPosition <= windowSize) {
                    xData.append(xPosition);
                    yData.append(sample.value);
                }
                x += 0.1; // 假设每次更新增加0.1秒
            }
        }

        // 在QCustomPlot中设置数据
        customPlot->graph(0)->setData(xData, yData);
        customPlot->replot();
    }

public:
    void setStartTime(double startTime)
    {
        currentTime = startTime;
    }

private:
    QCustomPlot *customPlot;
    int dataBufferMaxSize;
    QMutex dataMutex;
    QVector<ECGSample> dataBuffer;
    double windowSize;
    double currentTime;
    bool drawingPaused;

    DataSampler *dataSampler;
    QThread *dataSamplerThread;
    QTimer *timer;
};

class ECGMonitorManager : public QObject
{
    Q_OBJECT
public:
    ECGMonitorManager(QObject *parent = nullptr)
        : QObject(parent), startTime(0.0)
    {
        // 创建一个时间定时器，用于驱动ECG监视器的绘制
        timer = new QTimer(this);
        connect(timer, &QTimer::timeout, this, &ECGMonitorManager::updateMonitors);
        timer->start(100); // 设置每100毫秒更新一次

        // 创建多个ECG监视器
        for (int i = 0; i < 3; ++i) {
            QCustomPlot *customPlot = new QCustomPlot;
            customPlot->setMinimumSize(800, 200); // 设置最小大小
            ECGMonitor *monitor = new ECGMonitor(customPlot, startTime);
            monitors.append(QSharedPointer<ECGMonitor>(monitor));

            // 增加每个监视器的起始时间，以便它们在时间上错开
            startTime += 10.0; // 假设每个监视器的起始时间相差10秒
        }
    }

    void pauseAllMonitors(bool paused)
    {
        for (const QSharedPointer<ECGMonitor> &monitor : monitors) {
            monitor->pauseDrawing(paused);
        }
    }

private slots:
    void updateMonitors()
    {
        for (const QSharedPointer<ECGMonitor> &monitor : monitors) {
            monitor->updateImage();
        }
    }

private:
    QTimer *timer;
    QVector<QSharedPointer<ECGMonitor>> monitors;
    double startTime;
};

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    ECGMonitorManager manager;
    manager.pauseAllMonitors(false); // 启动时绘制
    return a.exec();
}
*/
